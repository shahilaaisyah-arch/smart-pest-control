Smart Pest Control - Website
---------------------------
This is a simple static website (HTML/CSS/JS) for the Smart Pest Control Robotic System.
To deploy on GitHub Pages:
1. Create a new public repository (e.g. smart-pest-control).
2. Upload all files and the 'assets' folder to the repository root.
3. In repo Settings -> Pages select Branch 'main' and folder '/ (root)'. Save.
4. Wait a few minutes and your site will be live at https://<your-username>.github.io/<repo-name>/
